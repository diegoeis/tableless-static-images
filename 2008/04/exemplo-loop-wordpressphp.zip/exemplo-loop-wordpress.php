<?php include (TEMPLATEPATH . '/searchform.php'); ?>

	<?php while (have_posts()) : the_post(); ?>
		<h1><?php the_title(); ?></h1>

		<div id="texto">
			<?php the_content('Read the rest of this entry &raquo;'); ?>
			<small><?php the_time('F jS, Y') ?>  por <?php the_author() ?> </small>
		</div>

<?php endwhile; ?>
