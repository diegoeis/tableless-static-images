<?php defined('_JEXEC') or die('Acesso restrito!'); ?>
<!DOCTYPE html>
<html lang="<?php echo $this->language; ?>">
<head>
	<jdoc:include type="head" />
	<link rel="stylesheet" href="<?php echo $this->baseurl; ?>/templates/<?php echo $this->template; ?>/css/style.css" type="text/css" />
</head>
<body>
	<header>
		<h1><?php echo $this->title; ?></h1>
		<nav><jdoc:include type="module" name="mainmenu" title="Menu" /></nav>
	</header>
	<section id="content">
		<article role="main">
			<jdoc:include type="message" />
			<jdoc:include type="component" />
		</article>
		<aside role="complementary">
			<jdoc:include type="modules" name="aside" />
		</aside>
	</section>
</body>
</html>